import LegalLayout from "@/app/components/LegalLayout";

export const metadata = {
  title: "Terms of Service — Escalate OS",
  description: "The terms and conditions governing use of the Escalate OS Governance Intelligence Platform.",
};

export default function TermsPage() {
  return (
    <LegalLayout title="Terms of Service" subtitle="Last updated: 7 November 2026">
      <p>These Terms govern your use of Escalate OS (&quot;the Platform&quot;). By accessing the Platform, you agree to these Terms.</p>

      <section>
        <h2 className="text-xl font-semibold text-white">1. Eligibility</h2>
        <p>The Platform is intended for use by enterprises, regulators, government-linked companies (GLCs), financial institutions, and critical infrastructure operators. You represent that you are authorised to act on behalf of your organisation.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">2. Licence &amp; Acceptable Use</h2>
        <ul className="ml-5 list-disc">
          <li>We grant you a non-exclusive, non-transferable licence to use the Platform for your internal governance and compliance operations.</li>
          <li>You agree not to misuse the Platform, upload unlawful content, or attempt to disrupt the service.</li>
          <li>You are responsible for the accuracy of the incident and regulatory data you submit.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">3. Your Data &amp; Responsibilities</h2>
        <p>You retain all rights to the data you submit. You are responsible for ensuring your use of the Platform complies with applicable Malaysian laws, including the PDPA 2010, and your sector-specific regulatory requirements.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">4. Service Availability</h2>
        <p>The Platform is provided on a commercially reasonable basis. We do not guarantee uninterrupted availability and are not liable for incidental downtime, except as required by applicable law.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">5. Intellectual Property</h2>
        <p>All Platform software, branding, and design remain the property of Escalate OS. Your submitted data remains yours.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">6. Termination</h2>
        <p>Either party may terminate access at any time. Upon termination, you may export your data; we will delete retained data per our Privacy Policy unless retention is required by law.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">7. Governing Law</h2>
        <p>These Terms are governed by the laws of Malaysia. Disputes shall be resolved in the courts of Malaysia.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">8. Contact</h2>
        <p>For questions about these Terms, contact <a href="mailto:legal@escalate.my" className="text-orange-400 hover:underline">legal@escalate.my</a>.</p>
      </section>
    </LegalLayout>
  );
}
