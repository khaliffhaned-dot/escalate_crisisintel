import LegalLayout from "@/app/components/LegalLayout";

export const metadata = {
  title: "Security — Escalate OS",
  description: "Security practices and controls for the Escalate OS Governance Intelligence Platform.",
};

export default function SecurityPage() {
  return (
    <LegalLayout title="Security" subtitle="How Escalate OS protects your data and operations">
      <p>Security is foundational to Escalate OS. The Platform is built for enterprises, regulators, GLCs, financial institutions, and critical infrastructure where the consequences of a breach are severe.</p>

      <section>
        <h2 className="text-xl font-semibold text-white">1. Encryption</h2>
        <ul className="ml-5 list-disc">
          <li><strong>In transit:</strong> All traffic is encrypted with TLS 1.2+ and enforced via HSTS (HTTP Strict Transport Security) with preload.</li>
          <li><strong>At rest:</strong> Evidence and stored data are encrypted in object storage.</li>
          <li><strong>SSL/TLS mode:</strong> Full (Strict) — Cloudflare presents valid certificates and verifies origin identity.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">2. Access Control</h2>
        <ul className="ml-5 list-disc">
          <li>Role-based access for administrators, compliance officers, and board members.</li>
          <li>Audit trail logging for every authentication and privileged action.</li>
          <li>Bot and automated abuse protection at the edge.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">3. Data Integrity &amp; Audit Trail</h2>
        <p>Every decision, action, and evidence upload is recorded in an immutable audit trail. Records cannot be altered or deleted, supporting regulatory accountability and post-incident review.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">4. Infrastructure</h2>
        <p>The Platform runs on Cloudflare&apos;s global edge network with DDoS protection, Web Application Firewall, and managed TLS. Compute and storage are isolated per deployment.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">5. Compliance Alignment</h2>
        <ul className="ml-5 list-disc">
          <li>Personal Data Protection Act (PDPA) 2010 — see our Privacy Policy.</li>
          <li>Sector regulators: JPDP, BNM, SC, Bursa Malaysia, MCMC.</li>
          <li>Immutable evidence retention for regulatory examination.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">6. Reporting a Vulnerability</h2>
        <p>If you believe you have identified a security vulnerability, please report it responsibly to <a href="mailto:security@escalate.my" className="text-orange-400 hover:underline">security@escalate.my</a>. We acknowledge reports within 48 hours.</p>
      </section>
    </LegalLayout>
  );
}
