import Link from "next/link";
import type { ReactNode } from "react";

export default function LegalLayout({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-zinc-950">
      <div
        className="pointer-events-none fixed inset-0 z-0 opacity-30"
        style={{
          backgroundImage:
            "linear-gradient(rgba(249,115,22,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(249,115,22,0.04) 1px, transparent 1px)",
          backgroundSize: "50px 50px",
          maskImage:
            "radial-gradient(ellipse 100% 80% at 50% 0%, #000 30%, transparent 80%)",
        }}
      />
      <div className="relative z-10 mx-auto max-w-[820px] px-5 pb-24 pt-28 sm:px-8 lg:px-12">
        <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm font-medium text-slate-400 transition-colors hover:text-white">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="19" y1="12" x2="5" y2="12" />
            <polyline points="12 19 5 12 12 5" />
          </svg>
          Back to Escalate OS
        </Link>

        <h1 className="mb-3 text-3xl font-extrabold tracking-tight sm:text-4xl">{title}</h1>
        <p className="mb-10 text-base text-slate-400">{subtitle}</p>

        <div className="legal-prose flex flex-col gap-6 text-[15px] leading-relaxed text-slate-300">
          {children}
        </div>

        <div className="mt-16 border-t border-white/[0.08] pt-6 text-xs text-slate-500">
          © 2026 Escalate OS. Governance Intelligence Platform.
        </div>
      </div>
    </div>
  );
}
