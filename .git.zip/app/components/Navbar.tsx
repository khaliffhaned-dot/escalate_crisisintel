"use client";

import { useState } from "react";
import Link from "next/link";

const NAV_LINKS = [
  { href: "#inside", label: "Inside Escalate OS" },
  { href: "#pillars", label: "Features" },
  { href: "#regulatory", label: "Regulatory Intelligence" },
  { href: "#board", label: "Board Intelligence" },
  { href: "#mcp", label: "MCP Ecosystem" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed inset-x-0 top-0 z-50 flex items-center justify-between border-b border-white/[0.08] bg-black/65 px-5 py-3 backdrop-blur-xl sm:px-8 sm:py-3.5 lg:px-12">
      <Link href="/" className="flex items-center gap-2.5">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
          <path d="M14 2L3 7v6c0 5.5 4.5 10.5 11 13 6.5-2.5 11-7.5 11-13V7L14 2z" stroke="#F97316" strokeWidth="2" fill="rgba(249,115,22,0.15)" />
          <path d="M14 9v6M14 18v.5" stroke="#FB923C" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="leading-tight">
          <span className="text-[18px] font-extrabold tracking-wider">ESCALATE</span>
          <br />
          <span className="text-[13px] font-semibold uppercase tracking-wider text-slate-500">Governance Intelligence</span>
        </div>
      </Link>

      {/* Desktop links */}
      <div className="hidden items-center gap-8 md:flex">
        {NAV_LINKS.map((l) => (
          <a key={l.href} href={l.href} className="text-sm font-medium text-slate-400 transition-all hover:-translate-y-px hover:text-white">
            {l.label}
          </a>
        ))}
      </div>

      {/* Desktop CTAs */}
      <div className="hidden items-center gap-3 md:flex">
        <Link href="/dashboard" className="btn-ghost">Sign In</Link>
        <Link href="/dashboard" className="btn-primary">Get Started</Link>
      </div>

      {/* Mobile hamburger */}
      <button
        type="button"
        aria-label="Toggle menu"
        onClick={() => setOpen((v) => !v)}
        className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.03] text-white md:hidden"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          {open ? (
            <>
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </>
          ) : (
            <>
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </>
          )}
        </svg>
      </button>

      {/* Mobile menu */}
      {open && (
        <div className="absolute inset-x-0 top-full flex flex-col gap-1 border-b border-white/[0.08] bg-black/95 px-5 py-4 backdrop-blur-xl md:hidden">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 text-sm font-medium text-slate-300 transition-colors hover:bg-white/[0.05] hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <div className="mt-2 flex flex-col gap-2 border-t border-white/[0.08] pt-3">
            <Link href="/dashboard" onClick={() => setOpen(false)} className="btn-ghost text-center">Sign In</Link>
            <Link href="/dashboard" onClick={() => setOpen(false)} className="btn-primary text-center">Get Started</Link>
          </div>
        </div>
      )}
    </nav>
  );
}
