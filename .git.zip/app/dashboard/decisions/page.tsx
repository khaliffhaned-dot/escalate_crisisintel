import Link from "next/link";
import RoomHeader from "../_components/RoomHeader";
import { DECISIONS } from "@/lib/sample-data";

const statusStyles: Record<string, string> = {
  Pending: "bg-amber-50 text-amber-700 border-amber-200",
  Approved: "bg-green-50 text-green-700 border-green-200",
  Rejected: "bg-red-50 text-red-700 border-red-200",
  Review: "bg-blue-50 text-blue-700 border-blue-200",
};

export default function DecisionQueue() {
  const pending = DECISIONS.filter((d) => d.status === "Pending").length;
  return (
    <div>
      <RoomHeader question="Track every decision, rationale, and approval."
        title="Decision Queue"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-orange-700">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            New Decision
          </button>
        }
      />

      <div className="mb-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { l: "Total decisions", v: DECISIONS.length },
          { l: "Pending approval", v: pending, t: "text-amber-600" },
          { l: "Approved", v: DECISIONS.filter((d) => d.status === "Approved").length, t: "text-green-600" },
          { l: "Auditability", v: "Full", t: "text-slate-900" },
        ].map((s) => (
          <div key={s.l} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className={`text-2xl font-bold ${s.t ?? "text-slate-900"}`}>{s.v}</div>
            <div className="mt-1 text-xs font-medium text-slate-500">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {DECISIONS.map((d) => (
          <div key={d.id} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] text-slate-400">{d.id}</span>
                  <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${statusStyles[d.status]}`}>{d.status}</span>
                </div>
                <div className="mt-1 text-sm font-semibold text-slate-900">{d.decision}</div>
              </div>
              <Link href={`/dashboard/incidents/${d.incidentId}`} className="shrink-0 rounded-lg bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-600 hover:bg-red-100">{d.due}</Link>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-500 sm:grid-cols-3">
              <span>Owner: <span className="font-medium text-slate-700">{d.owner}</span></span>
              <span>Approver: <span className="font-medium text-slate-700">{d.approver}</span></span>
              <span>Incident: <span className="font-mono text-slate-700">{d.incidentId}</span></span>
            </div>
            <div className="mt-2 text-xs text-slate-500">Rationale: <span className="text-slate-700">{d.rationale}</span></div>
            {d.status === "Pending" && (
              <div className="mt-3 flex gap-2">
                <button className="rounded-lg bg-orange-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-orange-700">Approve</button>
                <button className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50">Reject</button>
                <button className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50">Request More Info</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
