"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { INCIDENTS, ACTIVE_INCIDENT, severityStyles } from "@/lib/sample-data";

const NAV = [
  { href: "/dashboard/incidents", label: "Incidents", icon: "incidents" },
  { href: "/dashboard/regulatory", label: "Obligations Engine", icon: "rules" },
  { href: "/dashboard/evidence", label: "Evidence", icon: "evidence" },
  { href: "/dashboard/decisions", label: "Decisions", icon: "decisions" },
  { href: "/dashboard/statements", label: "Statements", icon: "statements" },
  { href: "/dashboard/board", label: "Board Briefs", icon: "board" },
];

function Icon({ name }: { name: string }) {
  const c = { width: 18, height: 18, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.75, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (name) {
    case "incidents":
      return (<svg {...c}><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>);
    case "rules":
      return (<svg {...c}><path d="M12 3v18M7 21h10M5 7h14M5 7l-2.5 6h5L5 7zm14 0l-2.5 6h5L19 7z" /></svg>);
    case "evidence":
      return (<svg {...c}><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" /></svg>);
    case "decisions":
      return (<svg {...c}><polyline points="9 11 12 14 22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>);
    case "statements":
      return (<svg {...c}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2" /></svg>);
    case "board":
      return (<svg {...c}><path d="M9 2h6a2 2 0 0 1 2 2v18l-5-3-5 3V4a2 2 0 0 1 2-2z" /></svg>);
    case "settings":
      return (<svg {...c}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>);
    default:
      return null;
  }
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [incidentId, setIncidentId] = useState(ACTIVE_INCIDENT.id);
  const incident = INCIDENTS.find((i) => i.id === incidentId) ?? ACTIVE_INCIDENT;
  const isActive = (href: string) => pathname === href || pathname?.startsWith(href + "/");

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-60 flex-col border-r border-slate-200 bg-white transition-transform lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center gap-2.5 px-5 py-5">
          <svg width="26" height="26" viewBox="0 0 28 28" fill="none">
            <path d="M14 2L3 7v6c0 5.5 4.5 10.5 11 13 6.5-2.5 11-7.5 11-13V7L14 2z" stroke="#ea580c" strokeWidth="2" fill="rgba(234,88,12,0.12)" />
            <path d="M14 9v6M14 18v.5" stroke="#fb923c" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <div className="leading-tight">
            <div className="text-sm font-extrabold tracking-wide text-slate-900">ESCALATE</div>
            <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400">Governance Intelligence</div>
          </div>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-2">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${isActive(item.href) ? "bg-orange-50 text-orange-700" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`}>
              <span className={isActive(item.href) ? "text-orange-600" : "text-slate-400"}><Icon name={item.icon} /></span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="border-t border-slate-200 px-3 py-3">
          <div className="mb-1.5 px-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Active Incident</div>
          <select value={incidentId} onChange={(e) => setIncidentId(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500">
            {INCIDENTS.map((i) => (<option key={i.id} value={i.id}>{i.id} — {i.title}</option>))}
          </select>
          <div className="mt-2 flex items-center gap-2 px-1">
            <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${severityStyles[incident.severity]}`}>{incident.severity}</span>
            <span className="text-[11px] text-slate-400">{incident.status} · {incident.updatedAt}</span>
          </div>
        </div>

        <div className="border-t border-slate-200 px-3 py-3">
          <Link href="/dashboard/settings" className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${pathname === "/dashboard/settings" ? "bg-orange-50 text-orange-700" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`}>
            <span className={pathname === "/dashboard/settings" ? "text-orange-600" : "text-slate-400"}><Icon name="settings" /></span>
            Settings
          </Link>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <div className="lg:pl-60">
        <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-2.5 sm:px-6">
            <button onClick={() => setSidebarOpen(true)} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 lg:hidden" aria-label="Open menu">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" /></svg>
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="truncate text-sm font-semibold text-slate-900">{incident.title}</span>
                <span className={`shrink-0 rounded border px-2 py-0.5 text-[11px] font-semibold ${severityStyles[incident.severity]}`}>{incident.severity}</span>
              </div>
              <div className="font-mono text-[11px] text-slate-400">{incident.id} · {incident.type}</div>
            </div>
            <div className="ml-auto hidden items-center gap-2 lg:flex">
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-1 text-xs">
                <span className="text-slate-400">Regulators</span>
                <span className="font-semibold text-slate-700">{incident.regulators.join(" | ")}</span>
              </div>
              <div className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-semibold ${incident.boardEscalation ? "border-red-200 bg-red-50 text-red-700" : "border-slate-200 text-slate-500"}`}>
                {incident.boardEscalation ? "Board Escalation Required" : "No Board Escalation"}
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">{incident.nextDeadline}</div>
            </div>
            <div className="ml-auto flex items-center gap-3 lg:ml-3">
              <div className="hidden items-center gap-2 rounded-lg border border-slate-200 px-3 py-1.5 text-sm text-slate-400 sm:flex">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
                Search…
              </div>
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-600 text-xs font-semibold text-white">MK</div>
            </div>
          </div>
        </header>

        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
