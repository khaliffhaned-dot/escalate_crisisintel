"use client";

import { useState } from "react";
import RoomHeader from "../_components/RoomHeader";
import { ACTIVE_INCIDENT } from "@/lib/sample-data";
import { TEMPLATES, TEMPLATE_IDS, type StatementTemplateId } from "@/lib/statement-templates";

type Lang = "English" | "Bahasa Malaysia" | "Dual";

const VARS = {
  title: ACTIVE_INCIDENT.title,
  org: "Escalate OS",
  date: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" }),
  spokesperson: "[Spokesperson]",
  contact: "media@escalate.my",
};

export default function StatementStudio() {
  const [template, setTemplate] = useState<StatementTemplateId>(TEMPLATE_IDS[0]);
  const [lang, setLang] = useState<Lang>("Dual");
  const [copied, setCopied] = useState(false);

  const en = TEMPLATES[template].en(VARS);
  const bm = TEMPLATES[template].bm(VARS);

  function copy(text: string) {
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div>
      <RoomHeader question="Templates drive the process. English, Bahasa Malaysia, or both."
        title="Statement Studio" />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Controls */}
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Template</div>
            <div className="space-y-1.5">
              {TEMPLATE_IDS.map((t) => (
                <button key={t} onClick={() => setTemplate(t)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-colors ${template === t ? "bg-orange-50 text-orange-700" : "text-slate-600 hover:bg-slate-50"}`}>
                  {t}
                  {template === t && <span className="text-orange-600">●</span>}
                </button>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Language</div>
            <div className="flex flex-col gap-1.5">
              {(["English", "Bahasa Malaysia", "Dual"] as Lang[]).map((l) => (
                <button key={l} onClick={() => setLang(l)}
                  className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${lang === l ? "bg-orange-50 text-orange-700" : "text-slate-600 hover:bg-slate-50"}`}>
                  {l}
                </button>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 text-xs text-slate-500 shadow-sm">
            <div className="font-semibold text-slate-700">Context</div>
            <div className="mt-1">Incident: <span className="font-mono">{ACTIVE_INCIDENT.id}</span></div>
            <div>Placeholders fill from the active incident. AI-assisted drafting is a Phase 2 enhancement.</div>
          </div>
        </div>

        {/* Preview */}
        <div className="lg:col-span-2">
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">{template}</h2>
              <button onClick={() => copy(lang === "Dual" ? `${en}\n\n---\n\n${bm}` : lang === "English" ? en : bm)}
                className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50">
                {copied ? "Copied ✓" : "Copy"}
              </button>
            </div>
            <div className="space-y-6">
              {(lang === "English" || lang === "Dual") && (
                <div>
                  {lang === "Dual" && <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">English</div>}
                  <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-800">{en}</pre>
                </div>
              )}
              {(lang === "Bahasa Malaysia" || lang === "Dual") && (
                <div>
                  {lang === "Dual" && <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Bahasa Malaysia</div>}
                  <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-800">{bm}</pre>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
