export default function RoomHeader({
  question,
  title,
  action,
}: {
  question: string;
  title: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <div className="text-sm font-medium text-orange-600">{question}</div>
        <h1 className="mt-0.5 text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
      </div>
      {action && <div className="flex items-center gap-2">{action}</div>}
    </div>
  );
}
