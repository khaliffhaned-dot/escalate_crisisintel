import RoomHeader from "../_components/RoomHeader";

const SECTIONS = [
  { title: "Organisation", items: ["Company name", "Industry sector", "Regulatory profile", "Operating regions"] },
  { title: "Team & Access", items: ["Members", "Roles & permissions", "Audit trail retention", "Single sign-on (SSO)"] },
  { title: "Integrations", items: ["Meltwater", "Dataminr", "Sprinklr", "Email / RSS / WhatsApp"] },
  { title: "Notifications", items: ["Incident alerts", "Deadline reminders", "Board escalations", "Daily digest"] },
];

export default function SettingsPage() {
  return (
    <div>
      <RoomHeader question="Configure your workspace" title="Settings" />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {SECTIONS.map((s) => (
          <div key={s.title} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-3 text-sm font-semibold text-slate-900">{s.title}</h2>
            <div className="divide-y divide-slate-100">
              {s.items.map((item) => (
                <div key={item} className="flex items-center justify-between py-2.5">
                  <span className="text-sm text-slate-600">{item}</span>
                  <span className="text-xs font-semibold text-slate-400">Manage →</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="mb-1 text-sm font-semibold text-slate-900">Appearance</h2>
        <p className="mb-3 text-xs text-slate-500">Light theme is the default application experience. Dark mode is available as a preference.</p>
        <div className="flex gap-2">
          <span className="rounded-lg border border-orange-200 bg-orange-50 px-3 py-1.5 text-xs font-semibold text-orange-700">Light (default)</span>
          <span className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-500">Dark</span>
          <span className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-500">System</span>
        </div>
      </div>
    </div>
  );
}
