import Link from "next/link";
import RoomHeader from "../_components/RoomHeader";
import { EVIDENCE, INCIDENTS } from "@/lib/sample-data";

const typeStyles: Record<string, string> = {
  Document: "bg-blue-50 text-blue-700 border-blue-200",
  Email: "bg-indigo-50 text-indigo-700 border-indigo-200",
  Screenshot: "bg-amber-50 text-amber-700 border-amber-200",
  Archive: "bg-slate-100 text-slate-600 border-slate-200",
  Letter: "bg-purple-50 text-purple-700 border-purple-200",
  PDF: "bg-red-50 text-red-700 border-red-200",
  URL: "bg-green-50 text-green-700 border-green-200",
};

export default function EvidenceRepository() {
  return (
    <div>
      <RoomHeader question="The crisis evidence chain — your moat."
        title="Evidence Repository"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-orange-700">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12" /></svg>
            Upload Evidence
          </button>
        }
      />

      <div className="mb-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { l: "Total items", v: EVIDENCE.length },
          { l: "Incidents covered", v: new Set(EVIDENCE.map((e) => e.incidentId)).size },
          { l: "Storage", v: "R2", t: "text-slate-900" },
          { l: "Chain integrity", v: "Verified", t: "text-green-600" },
        ].map((s) => (
          <div key={s.l} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className={`text-lg font-bold ${s.t ?? "text-slate-900"}`}>{s.v}</div>
            <div className="mt-1 text-xs font-medium text-slate-500">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200 bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
            <th className="px-5 py-3">Item</th><th className="px-5 py-3">Type</th><th className="hidden px-5 py-3 md:table-cell">Source</th><th className="hidden px-5 py-3 md:table-cell">Owner</th><th className="px-5 py-3">Time</th><th className="px-5 py-3">Incident</th>
          </tr></thead>
          <tbody className="divide-y divide-slate-100">
            {EVIDENCE.map((e, i) => {
              const inc = INCIDENTS.find((x) => x.id === e.incidentId);
              return (
                <tr key={e.id} className={`transition-colors hover:bg-slate-50 ${i % 2 ? "bg-slate-50/50" : ""}`}>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className="text-slate-400"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                      <div><div className="font-medium text-slate-800">{e.name}</div><div className="font-mono text-[11px] text-slate-400">{e.hash}</div></div>
                    </div>
                  </td>
                  <td className="px-5 py-3"><span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${typeStyles[e.type] ?? "bg-slate-100 text-slate-600 border-slate-200"}`}>{e.type}</span></td>
                  <td className="hidden px-5 py-3 text-slate-600 md:table-cell">{e.source}</td>
                  <td className="hidden px-5 py-3 text-slate-600 md:table-cell">{e.owner}</td>
                  <td className="px-5 py-3 text-slate-600">{e.time}</td>
                  <td className="px-5 py-3"><Link href={`/dashboard/incidents/${e.incidentId}`} className="font-mono text-xs font-semibold text-orange-600 hover:text-orange-700">{e.incidentId}</Link></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-xs text-slate-500">Each item is timestamped, owner-attributed, source-tagged, and linked to its incident. Real uploads stream to R2; this view shows the repository structure.</p>
    </div>
  );
}
