"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  INCIDENTS, TIMELINE, EVIDENCE, DECISIONS, STAKEHOLDERS, STATEMENTS, severityStyles, statusStyles, levelStyles,
} from "@/lib/sample-data";
import { OBLIGATIONS } from "@/lib/regulatory-rules";

const TABS = ["Overview", "Timeline", "Evidence", "Decisions", "Stakeholders", "Obligations", "Statements", "Board Briefs"] as const;
type Tab = (typeof TABS)[number];

export default function IncidentWorkspace() {
  const params = useParams();
  const id = (params?.id as string) ?? "INC-2026-014";
  const incident = INCIDENTS.find((i) => i.id === id) ?? INCIDENTS[0];
  const [tab, setTab] = useState<Tab>("Overview");

  const evidence = EVIDENCE.filter((e) => e.incidentId === incident.id);
  const decisions = DECISIONS.filter((d) => d.incidentId === incident.id);
  const statements = STATEMENTS.filter((s) => s.incidentId === incident.id);
  const obligations = OBLIGATIONS[incident.type as keyof typeof OBLIGATIONS] ?? [];
  const lvl = levelStyles[incident.level];

  const readiness = [
    { label: "Evidence captured", done: evidence.length > 0 },
    { label: "Initial statement prepared", done: statements.length > 0 },
    { label: "Decision owner assigned", done: decisions.length > 0 },
    { label: "Board brief generated", done: false },
    { label: "Regulatory notice submitted", done: false },
  ];

  const isL4 = incident.level === 4;

  return (
    <div>
      <div className="mb-4 flex items-center gap-2 text-sm">
        <Link href="/dashboard/incidents" className="text-slate-500 hover:text-slate-900">Incidents</Link>
        <span className="text-slate-300">/</span>
        <span className="font-mono text-slate-400">{incident.id}</span>
      </div>

      {/* Incident header */}
      <div className="mb-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${severityStyles[incident.severity]}`}>{incident.severity}</span>
              <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${statusStyles[incident.status]}`}>{incident.status}</span>
              <span className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-semibold text-slate-600">{incident.type}</span>
            </div>
            <h1 className="mt-2 text-xl font-bold text-slate-900">{incident.title}</h1>
          </div>
          <div className="flex gap-2">
            <Link href="/dashboard/statements" className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50">Statement</Link>
            <Link href="/dashboard/board" className="rounded-lg bg-orange-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-orange-700">Board Brief</Link>
          </div>
        </div>
      </div>

      {/* Severity Card — operational North Star */}
      <div className={`mb-5 flex items-center gap-4 rounded-xl border p-4 ${isL4 ? "border-slate-900 bg-slate-900" : `${lvl.border} ${lvl.bg}`}`}>
        <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl text-2xl font-extrabold ${isL4 ? "bg-white text-slate-900" : `${lvl.ring} text-white`}`}>{incident.level}</div>
        <div>
          <div className={`text-xs font-bold uppercase tracking-wider ${isL4 ? "text-white" : lvl.text}`}>{lvl.label} · {incident.severity}</div>
          <div className={`mt-1 text-sm ${isL4 ? "text-slate-300" : lvl.text}`}>{incident.severityReason}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-5 flex flex-wrap gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm font-medium transition-colors ${tab === t ? "border-orange-600 text-orange-700" : "border-transparent text-slate-500 hover:text-slate-900"}`}>
            {t}{t === "Decisions" && decisions.length ? ` (${decisions.length})` : t === "Evidence" && evidence.length ? ` (${evidence.length})` : ""}
          </button>
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        {tab === "Overview" && (
          <div className="space-y-5">
            {/* Readiness checklist */}
            <div>
              <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Readiness</div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {readiness.map((r) => (
                  <div key={r.label} className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm">
                    <span className={r.done ? "text-green-600" : "text-amber-500"}>{r.done ? "✅" : "⚠"}</span>
                    <span className={r.done ? "text-slate-700" : "text-slate-500"}>{r.label}</span>
                    {!r.done && <span className="ml-auto text-[11px] font-semibold text-amber-600">Outstanding</span>}
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                { l: "Evidence", v: evidence.length }, { l: "Decisions", v: decisions.length },
                { l: "Statements", v: statements.length }, { l: "Obligations", v: obligations.length },
              ].map((s) => (
                <div key={s.l} className="rounded-lg border border-slate-200 bg-slate-50 p-3"><div className="text-xl font-bold text-slate-900">{s.v}</div><div className="text-xs text-slate-500">{s.l}</div></div>
              ))}
            </div>
          </div>
        )}

        {tab === "Timeline" && (
          <div>
            <div className="mb-4 flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-500">
              <span className="text-green-600">●</span> Auto-generated — every action (evidence, decision, statement, brief) is logged here chronologically. Never rely on manual entry.
            </div>
            <ol className="relative space-y-4 border-l border-slate-200 pl-5">
              {TIMELINE.map((t) => (
                <li key={t.time} className="relative">
                  <span className="absolute -left-[26px] top-1 h-2.5 w-2.5 rounded-full border-2 border-white bg-orange-500" />
                  <div className="text-xs font-semibold text-slate-400">{t.time}</div>
                  <div className="text-sm text-slate-800">{t.event}</div>
                  <div className="text-xs text-slate-500">by {t.actor}</div>
                </li>
              ))}
            </ol>
          </div>
        )}

        {tab === "Evidence" && (
          <div>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-900">Evidence chain ({evidence.length})</span>
              <Link href="/dashboard/evidence" className="text-xs font-semibold text-orange-600 hover:text-orange-700">Open repository →</Link>
            </div>
            <div className="divide-y divide-slate-100">
              {evidence.map((e) => (
                <div key={e.id} className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className="text-slate-400"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                    <div><div className="text-sm font-medium text-slate-800">{e.name}</div><div className="text-xs text-slate-500">{e.type} · {e.source} · {e.owner} · {e.time}</div></div>
                  </div>
                  <span className="font-mono text-[11px] text-slate-400">{e.hash}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Decisions" && (
          <div>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-900">Decision queue ({decisions.length})</span>
              <Link href="/dashboard/decisions" className="text-xs font-semibold text-orange-600 hover:text-orange-700">Open queue →</Link>
            </div>
            <div className="space-y-3">
              {decisions.map((d) => (
                <div key={d.id} className="rounded-lg border border-slate-200 p-3">
                  <div className="flex items-center justify-between"><span className="text-sm font-semibold text-slate-900">{d.decision}</span>
                    <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${d.status === "Approved" ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>{d.status}</span>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-slate-500 sm:grid-cols-3">
                    <span>Owner: <span className="font-medium text-slate-700">{d.owner}</span></span>
                    <span>Approver: <span className="font-medium text-slate-700">{d.approver}</span></span>
                    <span>Due: <span className="font-medium text-red-600">{d.due}</span></span>
                  </div>
                  <div className="mt-2 text-xs text-slate-500">Rationale: <span className="text-slate-700">{d.rationale}</span></div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Stakeholders" && (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {STAKEHOLDERS.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-lg border border-slate-200 p-3">
                <div><div className="text-sm font-semibold text-slate-800">{s.name}</div><div className="text-xs text-slate-500">{s.position} · {s.relationship}</div></div>
                <span className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-semibold text-slate-600">{s.influence}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "Obligations" && (
          <div className="space-y-3">
            <div className="text-sm text-slate-500">Obligations Engine output for <span className="font-semibold text-slate-700">{incident.type}</span>:</div>
            {obligations.map((o, i) => (
              <div key={i} className="rounded-lg border border-slate-200 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-orange-100 text-xs font-bold text-orange-700">{i + 1}</span><span className="text-sm font-semibold text-slate-900">{o.obligation}</span></div>
                  <span className="shrink-0 rounded border border-amber-200 bg-amber-50 px-2 py-0.5 text-[11px] font-semibold text-amber-700">{o.status}</span>
                </div>
                <div className="mt-3 grid gap-2 text-xs sm:grid-cols-3">
                  <div><span className="font-semibold uppercase text-slate-400">Deadline</span><div className="font-semibold text-red-600">{o.deadline}</div></div>
                  <div><span className="font-semibold uppercase text-slate-400">Owner</span><div className="text-slate-700">{o.owner}</div></div>
                  <div><span className="font-semibold uppercase text-slate-400">Trigger</span><div className="text-slate-700">{o.trigger}</div></div>
                </div>
                <div className="mt-2 text-xs text-slate-500">Why: <span className="text-slate-700">{o.reason}</span> · <span className="text-slate-400">{o.regulator} ({o.regulation})</span></div>
              </div>
            ))}
          </div>
        )}

        {tab === "Statements" && (
          <div>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-900">Statements ({statements.length})</span>
              <Link href="/dashboard/statements" className="text-xs font-semibold text-orange-600 hover:text-orange-700">Open studio →</Link>
            </div>
            <div className="divide-y divide-slate-100">
              {statements.map((s) => (
                <div key={s.id} className="flex items-center justify-between py-3">
                  <div><div className="text-sm font-medium text-slate-800">{s.template}</div><div className="text-xs text-slate-500">{s.language} · last edited {s.lastEdited}</div></div>
                  <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${s.status === "Approved" || s.status === "Submitted" ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>{s.status}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Board Briefs" && (
          <div>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-900">Board briefing</span>
              <Link href="/dashboard/board" className="rounded-lg bg-orange-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-orange-700">Generate PDF →</Link>
            </div>
            <div className="space-y-3">
              {[
                { l: "Situation", b: `${incident.title} — ${incident.type} classified ${incident.severity} (Level ${incident.level}).` },
                { l: "Impact", b: "Financial, reputational, and regulatory exposure under assessment." },
                { l: "Exposure", b: `Regulators: ${incident.regulators.join(", ")}. Next deadline ${incident.nextDeadline}.` },
                { l: "Regulatory Status", b: `${obligations.length} obligations identified by the Obligations Engine.` },
                { l: "Decisions Needed", b: `${decisions.filter((d) => d.status === "Pending").length} decisions pending approval.` },
                { l: "Recommended Actions", b: "Approve pending notifications and public statement; ratify containment budget." },
              ].map((s) => (
                <div key={s.l} className="rounded-lg border border-slate-200 p-3"><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{s.l}</div><p className="mt-1 text-sm text-slate-700">{s.b}</p></div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
