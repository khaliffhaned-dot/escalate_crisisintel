import Link from "next/link";
import RoomHeader from "../_components/RoomHeader";
import { INCIDENTS, severityStyles, statusStyles } from "@/lib/sample-data";

export default function IncidentsList() {
  return (
    <div>
      <RoomHeader
        question="Every crisis becomes an incident file."
        title="Incidents"
        action={
          <Link href="/dashboard/incidents/INC-2026-014" className="inline-flex items-center gap-2 rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-orange-700">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            Create Incident
          </Link>
        }
      />

      <div className="mb-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { l: "Active", v: INCIDENTS.length },
          { l: "Critical / High", v: INCIDENTS.filter((i) => i.severity === "Critical" || i.severity === "High").length, t: "text-red-600" },
          { l: "Awaiting", v: INCIDENTS.filter((i) => i.status === "Awaiting").length },
          { l: "Board escalation", v: INCIDENTS.filter((i) => i.boardEscalation).length, t: "text-red-600" },
        ].map((s) => (
          <div key={s.l} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className={`text-2xl font-bold ${s.t ?? "text-slate-900"}`}>{s.v}</div>
            <div className="mt-1 text-xs font-medium text-slate-500">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200 bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
            <th className="px-5 py-3">Incident</th><th className="px-5 py-3">Type</th><th className="hidden px-5 py-3 md:table-cell">Regulators</th><th className="px-5 py-3">Deadline</th><th className="px-5 py-3">Status</th>
          </tr></thead>
          <tbody className="divide-y divide-slate-100">
            {INCIDENTS.map((i, idx) => (
              <Link key={i.id} href={`/dashboard/incidents/${i.id}`} as="tr" className={`flex cursor-pointer items-center transition-colors hover:bg-orange-50/40 ${idx % 2 ? "bg-slate-50/50" : ""}`}>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2">
                    <span className={`rounded border px-1.5 py-0.5 text-[11px] font-semibold ${severityStyles[i.severity]}`}>{i.severity}</span>
                    <span className="font-medium text-slate-800">{i.title}</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400">{i.id}</div>
                </td>
                <td className="px-5 py-3 text-slate-600">{i.type}</td>
                <td className="hidden px-5 py-3 md:table-cell"><span className="text-slate-600">{i.regulators.join(", ")}</span></td>
                <td className="px-5 py-3 font-semibold text-red-600">{i.nextDeadline}</td>
                <td className="px-5 py-3"><span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${statusStyles[i.status]}`}>{i.status}</span></td>
              </Link>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
