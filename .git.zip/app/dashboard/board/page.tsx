"use client";

import { useState } from "react";
import RoomHeader from "../_components/RoomHeader";
import { ACTIVE_INCIDENT } from "@/lib/sample-data";
import { fullPaper, chairmanBrief, boardResolution, actionTracker, signOff, type Block, type OutputId } from "@/lib/board-paper";

type Lang = "English" | "Bahasa Malaysia" | "Dual";
const OUTPUTS: OutputId[] = ["Chairman Brief", "Board Paper", "Board Resolution", "Action Tracker"];

function getBlocks(output: OutputId) {
  const inc = ACTIVE_INCIDENT;
  switch (output) {
    case "Chairman Brief": return chairmanBrief(inc);
    case "Board Paper": return [...fullPaper(inc), ...boardResolution(inc), ...actionTracker(inc), ...signOff()];
    case "Board Resolution": return boardResolution(inc);
    case "Action Tracker": return actionTracker(inc);
  }
}

function BlockView({ block, lang }: { block: Block; lang: Lang }) {
  const showEn = lang === "English" || lang === "Dual";
  const showBm = lang === "Bahasa Malaysia" || lang === "Dual";

  if (block.kind === "heading") {
    return <h2 className="mt-6 mb-2 border-b border-slate-200 pb-1 text-base font-bold text-slate-900">
      {block.num && <span className="mr-2 text-orange-600">{block.num}.</span>}{showEn && block.en}{showBm && (lang === "Dual" && block.bm ? <span className="block text-sm font-semibold text-slate-500">{block.bm}</span> : lang === "Bahasa Malaysia" ? block.bm : null)}
    </h2>;
  }
  if (block.kind === "subheading") {
    return <h3 className="mt-4 mb-1 text-sm font-semibold text-slate-700">{showEn ? block.en : ""}{showBm && lang === "Dual" ? <span className="ml-2 text-slate-400">· {block.bm}</span> : showBm ? block.bm : ""}</h3>;
  }
  if (block.kind === "prose") {
    return <div className="mb-3">
      {showEn && <p className="text-sm leading-relaxed text-slate-700">{block.en}</p>}
      {showBm && lang === "Dual" && <p className="mt-1 text-sm leading-relaxed text-slate-500 italic">{block.bm}</p>}
      {showBm && lang === "Bahasa Malaysia" && <p className="text-sm leading-relaxed text-slate-700">{block.bm}</p>}
    </div>;
  }
  if (block.kind === "list") {
    return <ul className="mb-3 ml-5 list-disc space-y-1">
      {(showEn ? block.en : showBm ? block.bm : []).map((item, i) => <li key={i} className="text-sm text-slate-700">{item}{showBm && lang === "Dual" && block.bm[i] ? <span className="block text-slate-500 italic">{block.bm[i]}</span> : null}</li>)}
    </ul>;
  }
  if (block.kind === "table") {
    return <div className="mb-4 overflow-x-auto"><table className="w-full border-collapse text-sm">
      <thead><tr>{block.headers.map((h) => <th key={h} className="border border-slate-200 bg-slate-50 px-3 py-1.5 text-left font-semibold text-slate-700">{h}</th>)}</tr></thead>
      <tbody>{block.rows.map((row, i) => <tr key={i} className="even:bg-slate-50/50">{row.map((cell, j) => <td key={j} className="border border-slate-200 px-3 py-1.5 text-slate-700">{cell}</td>)}</tr>)}</tbody>
    </table></div>;
  }
  return null;
}

export default function BoardBriefingGenerator() {
  const [output, setOutput] = useState<OutputId>("Board Paper");
  const [lang, setLang] = useState<Lang>("Dual");
  const [generated, setGenerated] = useState(false);
  const blocks = getBlocks(output);

  return (
    <div>
      <RoomHeader question="One source of truth. Four board-ready outputs. Bilingual."
        title="Board Briefing Generator"
        action={
          <div className="flex gap-2">
            <button onClick={() => setGenerated(true)} className="rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-orange-700">Generate</button>
            {generated && <button onClick={() => window.print()} className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50">Export PDF</button>}
          </div>
        }
      />

      {/* Controls */}
      <div className="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Output</div>
          <div className="flex flex-wrap gap-2">
            {OUTPUTS.map((o) => <button key={o} onClick={() => { setOutput(o); setGenerated(true); }} className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${output === o ? "border-orange-300 bg-orange-50 text-orange-700" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>{o}</button>)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Language</div>
          <div className="flex gap-2">
            {(["English", "Bahasa Malaysia", "Dual"] as Lang[]).map((l) => <button key={l} onClick={() => setLang(l)} className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${lang === l ? "border-orange-300 bg-orange-50 text-orange-700" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>{l}</button>)}
          </div>
        </div>
      </div>

      {/* Generated paper */}
      {generated ? (
        <div id="board-paper" className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm sm:p-10">
          <div className="mb-4 text-center">
            <div className="text-[11px] font-bold uppercase tracking-wider text-orange-600">Strictly Confidential</div>
            <div className="mt-1 text-xs text-slate-400">{ACTIVE_INCIDENT.id} · {ACTIVE_INCIDENT.title} · {new Date().toLocaleDateString("en-GB")}</div>
          </div>
          {blocks.map((b, i) => <BlockView key={i} block={b} lang={lang} />)}
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <div className="text-sm text-slate-500">Select an output and click <span className="font-semibold text-slate-700">Generate</span>. The paper auto-pulls from the Incident Workspace, Evidence, Decisions, Obligations, and Statements.</div>
        </div>
      )}
    </div>
  );
}
