"use client";

import { useState } from "react";
import RoomHeader from "../_components/RoomHeader";
import { OBLIGATIONS, INCIDENT_TYPES, type IncidentType } from "@/lib/regulatory-rules";

const statusStyles: Record<string, string> = {
  Pending: "bg-amber-50 text-amber-700 border-amber-200",
  "In Progress": "bg-indigo-50 text-indigo-700 border-indigo-200",
  Complete: "bg-green-50 text-green-700 border-green-200",
};

export default function ObligationsEngine() {
  const [type, setType] = useState<IncidentType>(INCIDENT_TYPES[0]);
  const obligations = OBLIGATIONS[type];

  return (
    <div>
      <RoomHeader question="What must I do — and why?"
        title="Obligations Engine™" />

      <div className="mb-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">Incident type</div>
        <div className="flex flex-wrap gap-2">
          {INCIDENT_TYPES.map((t) => (
            <button key={t} onClick={() => setType(t)}
              className={`rounded-lg border px-3.5 py-2 text-sm font-semibold transition-colors ${type === t ? "border-orange-300 bg-orange-50 text-orange-700" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-4 text-sm text-slate-500">
        <span className="font-semibold text-slate-700">{obligations.length}</span> obligations for <span className="font-semibold text-slate-700">{type}</span>
      </div>

      <div className="space-y-4">
        {obligations.map((o, i) => (
          <div key={i} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            {/* Obligation + status first */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-orange-100 text-xs font-bold text-orange-700">{i + 1}</span>
                <h3 className="text-base font-semibold text-slate-900">{o.obligation}</h3>
              </div>
              <span className={`shrink-0 rounded border px-2 py-0.5 text-[11px] font-semibold ${statusStyles[o.status]}`}>{o.status}</span>
            </div>

            {/* Deadline · Owner · Evidence — before legal references */}
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <div><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Deadline</div><div className="mt-1 text-sm font-semibold text-red-600">{o.deadline}</div></div>
              <div><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Owner</div><div className="mt-1 text-sm text-slate-700">{o.owner}</div></div>
              <div><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Evidence required</div><div className="mt-1 flex flex-wrap gap-1">{o.evidence.map((e) => <span key={e} className="rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[11px] text-slate-600">{e}</span>)}</div></div>
            </div>

            {/* Explainability — Why? */}
            <div className="mt-4 rounded-lg bg-slate-50 p-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <div><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Why — Reason</div><div className="mt-0.5 text-sm text-slate-700">{o.reason}</div></div>
                <div><div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Why — Trigger</div><div className="mt-0.5 text-sm text-slate-700">{o.trigger}</div></div>
              </div>
            </div>

            {/* Legal reference — last */}
            <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
              <span className="font-semibold text-slate-500">{o.regulator}</span>
              <span>·</span>
              <span>{o.regulation}</span>
              <span>·</span>
              <span>Escalation: {o.escalation}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
