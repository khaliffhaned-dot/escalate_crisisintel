import LegalLayout from "@/app/components/LegalLayout";

export const metadata = {
  title: "Privacy Policy — Escalate OS",
  description: "How Escalate OS collects, uses, and protects personal data in compliance with Malaysia's PDPA 2010.",
};

export default function PrivacyPage() {
  return (
    <LegalLayout title="Privacy Policy" subtitle="Last updated: 7 November 2026">
      <p>
        Escalate OS (&quot;we&quot;, &quot;us&quot;) operates the Governance Intelligence Platform for critical organizations in Malaysia. This policy explains how we collect, use, and protect personal data in accordance with the <strong>Personal Data Protection Act 2010 (PDPA)</strong> and the regulations of the Personal Data Protection Department (JPDP).
      </p>

      <section>
        <h2 className="text-xl font-semibold text-white">1. Data We Collect</h2>
        <ul className="ml-5 list-disc">
          <li><strong>Account data:</strong> name, work email, organisation, role.</li>
          <li><strong>Incident data:</strong> signals, evidence, board briefs, and regulatory mappings you create.</li>
          <li><strong>Usage data:</strong> audit trail entries, login times, and feature interactions.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">2. How We Use Your Data</h2>
        <ul className="ml-5 list-disc">
          <li>To provide the Escalate OS governance, regulatory, and board intelligence services.</li>
          <li>To generate audit trails and evidence records for regulatory compliance.</li>
          <li>To improve the platform&apos;s accuracy and reliability.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">3. Data Residency &amp; Storage</h2>
        <p>
          Data is processed and stored on Cloudflare&apos;s global edge network and associated storage services. Sensitive evidence is stored in encrypted object storage. We do not sell personal data to third parties.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">4. Your Rights Under PDPA</h2>
        <ul className="ml-5 list-disc">
          <li>Right to access and request a copy of your personal data.</li>
          <li>Right to correct inaccurate or incomplete data.</li>
          <li>Right to withdraw consent for processing.</li>
          <li>Right to limit processing for direct marketing.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">5. Data Retention</h2>
        <p>We retain personal data only as long as necessary to fulfil the purposes outlined above or as required by Malaysian law and your organisation&apos;s regulatory obligations.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">6. Contact</h2>
        <p>For privacy enquiries or to exercise your PDPA rights, contact our Data Protection Officer at <a href="mailto:dpo@escalate.my" className="text-orange-400 hover:underline">dpo@escalate.my</a>.</p>
      </section>
    </LegalLayout>
  );
}
