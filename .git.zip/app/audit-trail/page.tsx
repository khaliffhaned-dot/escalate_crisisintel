import LegalLayout from "@/app/components/LegalLayout";

export const metadata = {
  title: "Audit Trail — Escalate OS",
  description: "How Escalate OS maintains immutable audit trails for every decision and action.",
};

export default function AuditTrailPage() {
  return (
    <LegalLayout title="Audit Trail" subtitle="Immutable accountability for every decision and action">
      <p>Escalate OS maintains a tamper-evident audit trail that records every action taken within the Platform. This is core to regulatory accountability and post-incident review.</p>

      <section>
        <h2 className="text-xl font-semibold text-white">1. What We Record</h2>
        <ul className="ml-5 list-disc">
          <li>Incident creation, classification, and severity changes.</li>
          <li>Regulatory mapping and obligation assignments.</li>
          <li>Board brief generation and decision approvals.</li>
          <li>Evidence uploads and stakeholder notifications.</li>
          <li>User authentication and privileged actions.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">2. Immutability</h2>
        <p>Audit entries cannot be edited or deleted. Each entry is timestamped and attributed to an identified user, providing a defensible chain of custody for regulatory examination.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">3. Retention</h2>
        <p>Audit records are retained for the period required by applicable Malaysian law and your organisation&apos;s regulatory obligations. See our Privacy Policy for data retention details.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">4. Export &amp; Examination</h2>
        <p>Audit trails can be exported for regulatory examination or internal review. Contact <a href="mailto:compliance@escalate.my" className="text-orange-400 hover:underline">compliance@escalate.my</a> for assistance.</p>
      </section>
    </LegalLayout>
  );
}
