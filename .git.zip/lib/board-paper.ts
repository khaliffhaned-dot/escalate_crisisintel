// Board Paper engine — assembles a real, bilingual (EN/BM) board paper from the
// single source of truth: Incident Workspace + Evidence + Decisions + Obligations + Statements.
// Produces 4 outputs: Chairman Brief (1 page), Board Paper (full), Board Resolution, Action Tracker.

import { EVIDENCE, DECISIONS, STATEMENTS, TIMELINE, type Incident } from "./sample-data";
import { OBLIGATIONS } from "./regulatory-rules";

export type Block =
  | { kind: "heading"; num: string; en: string; bm: string }
  | { kind: "subheading"; en: string; bm: string }
  | { kind: "prose"; en: string; bm: string }
  | { kind: "list"; en: string[]; bm: string[] }
  | { kind: "table"; headers: string[]; rows: string[][] };

const today = () => new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" });

function ctx(incident: Incident) {
  return {
    evidence: EVIDENCE.filter((e) => e.incidentId === incident.id),
    decisions: DECISIONS.filter((d) => d.incidentId === incident.id),
    obligations: OBLIGATIONS[incident.type as keyof typeof OBLIGATIONS] ?? [],
    statements: STATEMENTS.filter((s) => s.incidentId === incident.id),
  };
}

// ---- Full Board Paper ----
export function fullPaper(incident: Incident): Block[] {
  const { evidence, decisions, obligations, statements } = ctx(incident);
  const pending = decisions.filter((d) => d.status === "Pending");
  const primaryDecision = pending[0] ?? decisions[0];

  const blocks: Block[] = [];

  // Title
  blocks.push({ kind: "heading", num: "", en: "BOARD PAPER — INCIDENT GOVERNANCE AND MANAGEMENT REPORT", bm: "KERTAS LEMBAGA PENGARAH — LAPORAN TADBIR URUS DAN PENGURUSAN INSIDEN" });

  // Document control
  blocks.push({ kind: "subheading", en: "Document Control", bm: "Kawalan Dokumen" });
  blocks.push({
    kind: "table",
    headers: ["Item", "Details"],
    rows: [
      ["Incident ID", incident.id],
      ["Incident Name", incident.title],
      ["Prepared By", "[Head of Risk & Governance]"],
      ["Reviewed By", "[Company Secretary]"],
      ["Submitted By", "[Chief Executive Officer]"],
      ["Board Meeting", "[Special Board Meeting]"],
      ["Date", today()],
      ["Classification", "Strictly Confidential"],
      ["Version", "1.0"],
    ],
  });

  // 1. Purpose
  blocks.push({ kind: "heading", num: "1", en: "Purpose of Paper", bm: "Tujuan Kertas" });
  blocks.push({ kind: "prose", en: "This paper is submitted to the Board of Directors to provide an update on the incident identified on [DATE], outline current impacts and exposures, seek approval for recommended actions and obtain direction from the Board regarding further escalation, disclosure and governance requirements.", bm: "Kertas ini dikemukakan kepada Lembaga Pengarah bagi memberikan kemas kini mengenai insiden yang dikenal pasti pada [TARIKH], menjelaskan impak dan pendedahan semasa, mendapatkan kelulusan bagi tindakan yang dicadangkan serta memperoleh panduan Lembaga berhubung keperluan eskalasi, pendedahan dan tadbir urus selanjutnya." });

  // 2. Executive Summary
  blocks.push({ kind: "heading", num: "2", en: "Executive Summary", bm: "Ringkasan Eksekutif" });
  blocks.push({ kind: "prose", en: `On [DATE/TIME], management became aware of an incident involving ${incident.title} (${incident.type}). Preliminary assessments indicate that the incident may affect business operations, regulatory obligations and stakeholder confidence. Management activated the Incident Response Framework immediately upon discovery and initiated containment, investigation, stakeholder engagement and governance procedures.`, bm: `Pada [TARIKH/MASA], pihak pengurusan dimaklumkan mengenai satu insiden melibatkan ${incident.title} (${incident.type}). Penilaian awal menunjukkan bahawa insiden ini berpotensi memberi kesan kepada operasi perniagaan, kewajipan kawal selia serta keyakinan pihak berkepentingan. Pihak pengurusan telah mengaktifkan Kerangka Tindak Balas Insiden serta-merta dan memulakan langkah pembendungan, siasatan, pengurusan pihak berkepentingan dan prosedur tadbir urus.` });
  blocks.push({ kind: "list", en: [`Incident remains ${incident.status === "Complete" ? "CONTAINED" : "ACTIVE"}`, `Investigation remains ${incident.status === "Complete" ? "COMPLETED" : "ONGOING"}`, "Regulatory assessment has been initiated", "Stakeholder communications are under preparation", "No fatalities have been reported", "No final root cause has been established"], bm: [`Insiden masih ${incident.status === "Complete" ? "TERKAWAL" : "AKTIF"}`, `Siasatan masih ${incident.status === "Complete" ? "SELESAI" : "BERJALAN"}`, "Penilaian kawal selia telah dimulakan", "Komunikasi pihak berkepentingan sedang disediakan", "Tiada kematian dilaporkan", "Punca sebenar masih belum dimuktamadkan"] });
  blocks.push({ kind: "prose", en: "Management seeks Board approval for the recommendations outlined in Section 10.", bm: "Pihak pengurusan memohon kelulusan Lembaga terhadap cadangan yang dinyatakan dalam Seksyen 10." });

  // 3. Incident Overview
  blocks.push({ kind: "heading", num: "3", en: "Incident Overview", bm: "Gambaran Keseluruhan Insiden" });
  blocks.push({ kind: "subheading", en: "What Happened", bm: "Apa Yang Berlaku" });
  blocks.push({ kind: "prose", en: `At approximately [TIME], [SOURCE] reported an incident involving ${incident.title}. Management verified the report through [SOURCE OF CONFIRMATION] and activated the incident response process. The matter was escalated to:`, bm: `Pada sekitar [MASA], [SUMBER] melaporkan satu insiden melibatkan ${incident.title}. Pihak pengurusan mengesahkan laporan tersebut melalui [SUMBER PENGESAHAN] dan mengaktifkan proses tindak balas insiden. Perkara ini telah dieskalasikan kepada:` });
  blocks.push({ kind: "list", en: ["Business Unit Head", "Executive Management", "CEO", "Company Secretary", "Incident Response Team"], bm: ["Ketua Unit Perniagaan", "Pengurusan Eksekutif", "CEO", "Setiausaha Syarikat", "Pasukan Tindak Balas Insiden"] });

  // 4. Timeline
  blocks.push({ kind: "heading", num: "4", en: "Incident Timeline", bm: "Garis Masa Insiden" });
  blocks.push({ kind: "table", headers: ["Time", "Event"], rows: TIMELINE.map((t) => [t.time, t.event]) });

  // 5. Regulatory Assessment
  blocks.push({ kind: "heading", num: "5", en: "Regulatory Assessment", bm: "Penilaian Kawal Selia" });
  blocks.push({ kind: "subheading", en: "Applicable Obligations", bm: "Kewajipan Berkaitan" });
  const oblRows = obligations.map((o) => [o.regulator, o.trigger, o.deadline, o.status]);
  const applicable = new Set(obligations.map((o) => o.regulator));
  if (!applicable.has("DOSH")) oblRows.push(["DOSH", "Workplace Impact", "N/A", "Not Triggered"]);
  if (!applicable.has("JAKIM")) oblRows.push(["JAKIM", "Halal Integrity Concern", "N/A", "Not Triggered"]);
  blocks.push({ kind: "table", headers: ["Authority", "Trigger", "Deadline", "Status"], rows: oblRows });
  blocks.push({ kind: "subheading", en: "Management Assessment", bm: "Penilaian Pengurusan" });
  blocks.push({ kind: "prose", en: `Management currently believes the incident may trigger reporting obligations under the following frameworks: ${obligations.map((o) => `${o.regulation}`).join("; ")}. Legal verification remains in progress.`, bm: `Pihak pengurusan berpandangan bahawa insiden ini berkemungkinan mencetuskan kewajipan pelaporan di bawah: ${obligations.map((o) => o.regulation).join("; ")}. Pengesahan undang-undang masih dijalankan.` });

  // 6. Evidence Summary
  blocks.push({ kind: "heading", num: "6", en: "Evidence Summary", bm: "Ringkasan Bukti" });
  blocks.push({ kind: "subheading", en: "Evidence Collected", bm: "Bukti Dikumpul" });
  blocks.push({ kind: "table", headers: ["Evidence Type", "Reference", "Status"], rows: evidence.map((e) => [e.type, e.id, e.incidentId === incident.id ? "Verified" : "Under Review"]) });
  blocks.push({ kind: "subheading", en: "Confidence Assessment", bm: "Penilaian Keyakinan" });
  blocks.push({ kind: "table", headers: ["Area", "Confidence"], rows: [["Incident Occurrence", "High"], ["Timeline Accuracy", "High"], ["Root Cause", "Medium"], ["Financial Impact", "Low"], ["Stakeholder Impact", "Medium"]] });

  // 7. Impact Assessment
  blocks.push({ kind: "heading", num: "7", en: "Impact Assessment", bm: "Penilaian Impak" });
  const impacts: [string, string, string, string][] = [
    ["People", "Individu", "Current impact on employees, contractors, customers or members of the public.", "Kesan semasa ke atas pekerja, kontraktor, pelanggan atau orang awam."],
    ["Operations", "Operasi", "Assessment of service interruption, business disruption and recovery status.", "Penilaian gangguan perkhidmatan, gangguan perniagaan dan status pemulihan."],
    ["Financial", "Kewangan", "Estimated exposure: RM [AMOUNT]. Current assessment confidence: Low / Medium / High.", "Anggaran pendedahan: RM [JUMLAH]. Keyakinan penilaian semasa: Rendah / Sederhana / Tinggi."],
    ["Reputational", "Reputasi", "Assessment of media, public attention and stakeholder confidence.", "Penilaian media, perhatian awam dan keyakinan pihak berkepentingan."],
    ["Regulatory", "Kawal Selia", "Potential enforcement, reporting obligations or investigation risks.", "Potensi penguatkuasaan, kewajipan pelaporan atau risiko siasatan."],
  ];
  impacts.forEach((im) => { blocks.push({ kind: "subheading", en: im[0], bm: im[1] }); blocks.push({ kind: "prose", en: im[2], bm: im[3] }); });

  // 8. Decision Justification
  blocks.push({ kind: "heading", num: "8", en: "Decision Justification", bm: "Justifikasi Keputusan" });
  blocks.push({ kind: "subheading", en: "Decision Requested", bm: "Keputusan Dimohon" });
  blocks.push({ kind: "prose", en: primaryDecision ? primaryDecision.decision : "[Decision to be confirmed].", bm: primaryDecision ? primaryDecision.decision : "[Keputusan untuk disahkan]." });
  blocks.push({ kind: "subheading", en: "Why Management Recommends This", bm: "Sebab Cadangan Dikemukakan" });
  blocks.push({ kind: "list", en: ["Improve credibility", "Strengthen regulatory confidence", "Support Board oversight", "Improve evidence quality"], bm: ["Meningkatkan kredibiliti", "Mengukuhkan keyakinan pihak berkuasa", "Menyokong pengawasan Lembaga", "Meningkatkan kualiti bukti"] });
  blocks.push({ kind: "subheading", en: "Alternatives Considered", bm: "Pilihan Yang Dipertimbangkan" });
  blocks.push({ kind: "list", en: ["Option A — Internal investigation only.", "Option B — Hybrid investigation.", "Option C — Full independent investigation. (Recommended)"], bm: ["Pilihan A — Siasatan dalaman sahaja.", "Pilihan B — Siasatan campuran.", "Pilihan C — Siasatan bebas penuh. (Dicadangkan)"] });

  // 9. Risks of Non-Approval
  blocks.push({ kind: "heading", num: "9", en: "Risks of Non-Approval", bm: "Risiko Jika Tidak Diluluskan" });
  blocks.push({ kind: "list", en: ["Reduced stakeholder confidence", "Delayed investigations", "Increased regulatory scrutiny", "Increased legal risk", "Reputational deterioration"], bm: ["Penurunan keyakinan pihak berkepentingan", "Kelewatan siasatan", "Pemerhatian lebih ketat oleh regulator", "Risiko undang-undang yang lebih tinggi", "Kemerosotan reputasi"] });

  // 10. Recommendations
  blocks.push({ kind: "heading", num: "10", en: "Management Recommendations", bm: "Cadangan Pengurusan" });
  blocks.push({ kind: "prose", en: "Management recommends that the Board:", bm: "Pihak pengurusan mencadangkan agar Lembaga:" });
  blocks.push({ kind: "list", en: [`Approve incident classification as Level ${incident.level}.`, "Approve stakeholder communication plan.", "Approve engagement of external specialists.", "Approve regulatory notification strategy.", "Approve Board monitoring cadence.", "Approve emergency expenditure of RM [AMOUNT]."], bm: [`Luluskan klasifikasi insiden sebagai Level ${incident.level}.`, "Luluskan pelan komunikasi pihak berkepentingan.", "Luluskan penglibatan pakar luar.", "Luluskan strategi pemberitahuan kawal selia.", "Luluskan kekerapan pemantauan Lembaga.", "Luluskan perbelanjaan kecemasan RM [JUMLAH]."] });

  // 11. Board Approvals Required
  blocks.push({ kind: "heading", num: "11", en: "Board Approvals Required", bm: "Kelulusan Lembaga Diperlukan" });
  blocks.push({ kind: "table", headers: ["Item", "Approve", "Reject"], rows: [["Incident Classification", "☐", "☐"], ["Regulatory Notification", "☐", "☐"], ["Public Communication", "☐", "☐"], ["External Investigation", "☐", "☐"], ["Emergency Budget", "☐", "☐"], ["Stakeholder Engagement Plan", "☐", "☐"]] });

  return blocks;
}

// ---- Board Resolution (standalone) ----
export function boardResolution(incident: Incident): Block[] {
  return [
    { kind: "heading", num: "12", en: "Board Resolution", bm: "Resolusi Lembaga" },
    { kind: "prose", en: `After consideration of the information contained herein, the Board resolves as follows regarding ${incident.title} (${incident.id}):`, bm: `Selepas meneliti maklumat yang terkandung di dalam ini, Lembaga memutuskan seperti berikut berhubung ${incident.title} (${incident.id}):` },
    { kind: "list", en: ["☐ Approved", "☐ Approved Subject to Conditions", "☐ Deferred Pending Further Information", "☐ Rejected"], bm: ["☐ Diluluskan", "☐ Diluluskan Dengan Syarat", "☐ Ditangguh Menunggu Maklumat Lanjut", "☐ Ditolak"] },
    { kind: "subheading", en: "Conditions", bm: "Syarat" },
    { kind: "prose", en: "______________________________________________", bm: "______________________________________________" },
    { kind: "subheading", en: "Comments", bm: "Ulasan" },
    { kind: "prose", en: "______________________________________________", bm: "______________________________________________" },
  ];
}

// ---- Action Tracker (standalone) ----
export function actionTracker(incident: Incident): Block[] {
  const { decisions } = ctx(incident);
  const rows = (decisions.length ? decisions : [
    { decision: "Notify Regulator", owner: "Legal", due: "[DATE]" },
    { decision: "Issue Statement", owner: "Communications", due: "[DATE]" },
    { decision: "Stakeholder Calls", owner: "CEO", due: "[DATE]" },
    { decision: "Board Update", owner: "Company Secretary", due: "[DATE]" },
    { decision: "Investigation Report", owner: "Risk", due: "[DATE]" },
  ]).map((d: any) => [d.decision, d.owner, d.due ?? "[DATE]", d.status ?? "Open"]);
  return [
    { kind: "heading", num: "13", en: "Action Tracker", bm: "Penjejak Tindakan" },
    { kind: "table", headers: ["Action", "Owner", "Due Date", "Status"], rows },
  ];
}

// ---- Sign-off ----
export function signOff(): Block[] {
  return [
    { kind: "heading", num: "14", en: "Sign-off", bm: "Pengesahan" },
    { kind: "table", headers: ["Position", "Name", "Signature"], rows: [["CEO", "", ""], ["CFO", "", ""], ["Company Secretary", "", ""], ["Chairman", "", ""], ["Audit & Risk Chair", "", ""]] },
  ];
}

// ---- Chairman Brief (1 page, condensed) ----
export function chairmanBrief(incident: Incident): Block[] {
  const { evidence, decisions, obligations } = ctx(incident);
  return [
    { kind: "heading", num: "", en: "CHAIRMAN BRIEF — 1 PAGE", bm: "RINGKASAN PENGARAH — 1 MUKA SURAT" },
    { kind: "subheading", en: "Document Control", bm: "Kawalan Dokumen" },
    { kind: "table", headers: ["Item", "Details"], rows: [["Incident ID", incident.id], ["Incident", incident.title], ["Level", `Level ${incident.level} — ${incident.severity}`], ["Date", today()], ["Classification", "Strictly Confidential"]] },
    { kind: "heading", num: "1", en: "Executive Summary", bm: "Ringkasan Eksekutif" },
    { kind: "prose", en: `${incident.title} — ${incident.type}, classified Level ${incident.level} (${incident.severity}). ${incident.severityReason}. Status: ${incident.status}. Next critical deadline: ${incident.nextDeadline}.`, bm: `${incident.title} — ${incident.type}, diklasifikasi Level ${incident.level} (${incident.severity}). ${incident.severityReason}. Status: ${incident.status}. Tempoh kritikal seterusnya: ${incident.nextDeadline}.` },
    { kind: "heading", num: "2", en: "Key Exposure", bm: "Pendedahan Utama" },
    { kind: "list", en: [`Regulators: ${incident.regulators.join(", ")}`, `Obligations: ${obligations.length} identified`, `Evidence: ${evidence.length} items captured`, `Decisions pending: ${decisions.filter((d) => d.status === "Pending").length}`], bm: [`Regulator: ${incident.regulators.join(", ")}`, `Kewajipan: ${obligations.length} dikenal pasti`, `Bukti: ${evidence.length} item dikumpul`, `Keputusan tertangguh: ${decisions.filter((d) => d.status === "Pending").length}`] },
    { kind: "heading", num: "3", en: "Recommendations", bm: "Cadangan" },
    { kind: "list", en: [`Approve incident classification as Level ${incident.level}.`, "Approve regulatory notification strategy.", "Approve stakeholder communication plan.", "Approve emergency expenditure of RM [AMOUNT]."], bm: [`Luluskan klasifikasi insiden sebagai Level ${incident.level}.`, "Luluskan strategi pemberitahuan kawal selia.", "Luluskan pelan komunikasi pihak berkepentingan.", "Luluskan perbelanjaan kecemasan RM [JUMLAH]."] },
  ];
}

export type OutputId = "Chairman Brief" | "Board Paper" | "Board Resolution" | "Action Tracker";
