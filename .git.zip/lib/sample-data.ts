// Sample data for Escalate OS rooms — demo-ready, wired to match the D1 schema later.
// Malaysia-relevant regulators: JPDP, BNM, SC, Bursa, MCMC, KKM, DOE, DOSH.

export type Severity = "Critical" | "High" | "Medium" | "Low";
export type Status = "Open" | "In Progress" | "Awaiting" | "Complete" | "Overdue";

export const INCIDENTS = [
  { id: "INC-2026-014", title: "Product Recall — Selangor Facility", type: "Product Recall", severity: "Critical" as Severity, level: 4, severityReason: "Consumer safety risk; KKM enquiry received; media coverage rising; executive attention required", status: "Open" as Status, regulators: ["JPDP", "KKM", "Bursa"], boardEscalation: true, nextDeadline: "2h 14m", updatedAt: "2m ago", signals: 14 },
  { id: "INC-2026-013", title: "Customer Data Breach — Vendor", type: "Data Breach", severity: "High" as Severity, level: 3, severityReason: "Personal data compromised; PDPA triggered; vendor notification received", status: "In Progress" as Status, regulators: ["JPDP", "BNM"], boardEscalation: true, nextDeadline: "6h 02m", updatedAt: "1h ago", signals: 9 },
  { id: "INC-2026-011", title: "Fake Announcement — Deepfake", type: "Fake Announcement / Deepfake", severity: "Medium" as Severity, level: 2, severityReason: "Brand impersonation; viral spread; MCMC platform escalation required", status: "Open" as Status, regulators: ["MCMC"], boardEscalation: false, nextDeadline: "1d 4h", updatedAt: "3h ago", signals: 22 },
  { id: "INC-2026-009", title: "Cyber Attack — Ransomware", type: "Cyber Attack", severity: "High" as Severity, level: 3, severityReason: "Operational disruption; BNM reportable; forensic engagement needed", status: "Awaiting" as Status, regulators: ["BNM", "MyCERT"], boardEscalation: true, nextDeadline: "3d", updatedAt: "5h ago", signals: 4 },
  { id: "INC-2026-007", title: "Environmental Incident — Johor", type: "Environmental Incident", severity: "Medium" as Severity, level: 2, severityReason: "Pollution containment; DOE notifiable; community impact", status: "In Progress" as Status, regulators: ["DOE", "DOSH"], boardEscalation: false, nextDeadline: "5d", updatedAt: "1d ago", signals: 6 },
];

// Severity level styling — Green / Amber / Red / Black (operational North Star)
export const levelStyles: Record<number, { label: string; bg: string; text: string; border: string; ring: string }> = {
  1: { label: "LEVEL 1", bg: "bg-green-50", text: "text-green-800", border: "border-green-300", ring: "bg-green-500" },
  2: { label: "LEVEL 2", bg: "bg-amber-50", text: "text-amber-800", border: "border-amber-300", ring: "bg-amber-500" },
  3: { label: "LEVEL 3", bg: "bg-red-50", text: "text-red-800", border: "border-red-300", ring: "bg-red-500" },
  4: { label: "LEVEL 4", bg: "bg-slate-900", text: "text-white", border: "border-slate-900", ring: "bg-slate-900" },
};

export const ACTIVE_INCIDENT = INCIDENTS[0];

// Signal-first model: Signal → Event → Correlation → Incident → Obligation → Decision
export const SIGNAL_EVENTS = [
  { id: "EVT-01", signal: "SIG-482", type: "Media", detail: "Recall coverage trending on national TV", correlated: true, incident: "INC-2026-014" },
  { id: "EVT-02", signal: "SIG-481", type: "Social", detail: "Viral post — 12K shares in 30 min", correlated: true, incident: "INC-2026-014" },
  { id: "EVT-03", signal: "SIG-480", type: "Regulator", detail: "KKM formal enquiry received", correlated: true, incident: "INC-2026-014" },
  { id: "EVT-04", signal: "SIG-479", type: "Market", detail: "Competitor issued similar recall", correlated: false, incident: null },
  { id: "EVT-05", signal: "SIG-478", type: "Regulatory", detail: "Bursa filing deadline reminder", correlated: false, incident: null },
];

// Incident Workspace — unified incident record
export const TIMELINE = [
  { time: "08:42", event: "Signal detected — Meltwater (national TV coverage)", actor: "System" },
  { time: "08:51", event: "Incident created and classified Critical", actor: "M. Khaliff" },
  { time: "09:03", event: "KKM formal enquiry received via email", actor: "Legal Counsel" },
  { time: "09:15", event: "Board escalation triggered", actor: "M. Khaliff" },
  { time: "09:28", event: "JPDP notification drafted (72h deadline started)", actor: "Legal Counsel" },
  { time: "09:40", event: "Evidence preservation snapshot captured to R2", actor: "IT Security" },
];

export const EVIDENCE = [
  { id: "EV-01", name: "QC defect report — Selangor line 3", type: "Document", source: "Quality Control", owner: "IT Security", incidentId: "INC-2026-014", stored: "R2", time: "09:40", hash: "a3f9…21c" },
  { id: "EV-02", name: "Media coverage compilation", type: "Archive", source: "Meltwater", owner: "Comms Lead", incidentId: "INC-2026-014", stored: "R2", time: "09:42", hash: "b7e1…09f" },
  { id: "EV-03", name: "KKM enquiry email (original)", type: "Email", source: "Email", owner: "Legal Counsel", incidentId: "INC-2026-014", stored: "R2", time: "09:03", hash: "c2d4…77a" },
  { id: "EV-04", name: "Social media virality snapshot", type: "Screenshot", source: "Twitter/X", owner: "Comms Lead", incidentId: "INC-2026-014", stored: "R2", time: "08:55", hash: "d8a0…3eb" },
  { id: "EV-05", name: "Vendor breach notification letter", type: "Letter", owner: "DPO", source: "Vendor", incidentId: "INC-2026-013", stored: "R2", time: "11:20", hash: "e5c2…1b4" },
  { id: "EV-06", name: "Forensic snapshot — affected systems", type: "PDF", owner: "CISO", source: "Forensics", incidentId: "INC-2026-009", stored: "R2", time: "14:02", hash: "f1a8…90d" },
  { id: "EV-07", name: "Deepfake video — original URL capture", type: "URL", owner: "Comms Lead", source: "Platform report", incidentId: "INC-2026-011", stored: "R2", time: "10:11", hash: "a09b…44e" },
];

export const DECISIONS = [
  { id: "DEC-01", decision: "Approve JPDP notification submission", owner: "Legal Counsel", due: "Today 5PM", approver: "CEO", status: "Pending", rationale: "72-hour deadline expiring; legal review complete", incidentId: "INC-2026-014" },
  { id: "DEC-02", decision: "Authorise public recall statement", owner: "Comms Lead", due: "Today 5PM", approver: "CEO", status: "Pending", rationale: "Media velocity rising; holding statement insufficient", incidentId: "INC-2026-014" },
  { id: "DEC-03", decision: "Suspend affected product line", owner: "COO", due: "Tomorrow", approver: "CEO", status: "Approved", rationale: "Containment to limit consumer exposure", incidentId: "INC-2026-014" },
  { id: "DEC-04", decision: "Engage external forensic firm", owner: "CISO", due: "2 days", approver: "CFO", status: "Pending", rationale: "Internal team at capacity; regulator expectation", incidentId: "INC-2026-009" },
  { id: "DEC-05", decision: "Issue MCMC platform escalation", owner: "Comms Lead", due: "Today", approver: "Legal Counsel", status: "Pending", rationale: "Deepfake spreading; platform takedown required", incidentId: "INC-2026-011" },
];

export const STATEMENTS = [
  { id: "ST-01", template: "Holding Statement", language: "Dual", status: "Approved", incidentId: "INC-2026-014", lastEdited: "09:50" },
  { id: "ST-02", template: "Media Statement", language: "English", status: "Draft", incidentId: "INC-2026-014", lastEdited: "10:12" },
  { id: "ST-03", template: "Regulator Notice", language: "English", status: "Submitted", incidentId: "INC-2026-013", lastEdited: "11:30" },
  { id: "ST-04", template: "Customer Advisory", language: "Bahasa Malaysia", status: "Draft", incidentId: "INC-2026-013", lastEdited: "12:05" },
];

export const AUDIT_TRAIL = [
  { time: "09:40", actor: "IT Security", action: "Captured evidence snapshot EV-01 to R2", ip: "10.0.4.12" },
  { time: "09:28", actor: "Legal Counsel", action: "Created obligation OBL-01 (JPDP 72h)", ip: "10.0.4.31" },
  { time: "09:15", actor: "M. Khaliff", action: "Triggered board escalation for INC-2026-014", ip: "10.0.4.05" },
  { time: "08:51", actor: "M. Khaliff", action: "Created incident INC-2026-014 (Critical)", ip: "10.0.4.05" },
  { time: "08:42", actor: "System", action: "Signal SIG-482 correlated to new incident", ip: "—" },
];

export const SIGNALS = [
  { id: "SIG-482", source: "Meltwater", title: "Recall coverage trending on national TV", severity: "High" as Severity, time: "8m ago" },
  { id: "SIG-481", source: "Twitter/X", title: "Viral post — 12K shares in 30 min", severity: "Medium" as Severity, time: "22m ago" },
  { id: "SIG-480", source: "Email", title: "KKM formal enquiry received", severity: "High" as Severity, time: "1h ago" },
  { id: "SIG-479", source: "Dataminr", title: "Competitor issued similar recall", severity: "Low" as Severity, time: "2h ago" },
  { id: "SIG-478", source: "RSS", title: "Bursa filing deadline reminder", severity: "Medium" as Severity, time: "4h ago" },
];

export const OBLIGATIONS = [
  { id: "OBL-01", title: "Notify JPDP within 72 hours", regulator: "JPDP", owner: "Legal Counsel", deadline: "2h 14m left", status: "Overdue" as Status, priority: "Critical" as Severity },
  { id: "OBL-02", title: "Board escalation pack", regulator: "Internal", owner: "Company Secretary", deadline: "Due today", status: "In Progress" as Status, priority: "High" as Severity },
  { id: "OBL-03", title: "Public statement draft", regulator: "MCMC", owner: "Comms Lead", deadline: "Tomorrow", status: "Awaiting" as Status, priority: "High" as Severity },
  { id: "OBL-04", title: "Bursa material disclosure", regulator: "Bursa", owner: "CFO", deadline: "3 days", status: "Open" as Status, priority: "High" as Severity },
  { id: "OBL-05", title: "Evidence preservation log", regulator: "JPDP", owner: "IT Security", deadline: "Ongoing", status: "Complete" as Status, priority: "Medium" as Severity },
  { id: "OBL-06", title: "Stakeholder notification list", regulator: "Internal", owner: "Comms Lead", deadline: "1 day", status: "In Progress" as Status, priority: "Medium" as Severity },
  { id: "OBL-07", title: "Vendor breach assessment", regulator: "PDPA", owner: "DPO", deadline: "5 days", status: "Open" as Status, priority: "Medium" as Severity },
  { id: "OBL-08", title: "Regulatory fee submission", regulator: "SC", owner: "Finance", deadline: "2 weeks", status: "Open" as Status, priority: "Low" as Severity },
];

export const STAKEHOLDERS = [
  { id: "SH-01", name: "JPDP", type: "Regulator", influence: "Critical", position: "Monitoring", relationship: "Neutral", health: "Good" },
  { id: "SH-02", name: "Bursa Malaysia", type: "Market", influence: "High", position: "Pending", relationship: "Cooperative", health: "Good" },
  { id: "SH-03", name: "Ministry of Health", type: "Regulator", influence: "High", position: "Engaged", relationship: "Cooperative", health: "Good" },
  { id: "SH-04", name: "Retail Investors", type: "Public", influence: "Medium", position: "Monitoring", relationship: "Neutral", health: "At Risk" },
  { id: "SH-05", name: "National Media", type: "Media", influence: "High", position: "Adversarial", relationship: "Tense", health: "At Risk" },
  { id: "SH-06", name: "Affected Customers", type: "Public", influence: "High", position: "Impacted", relationship: "Strained", health: "Poor" },
  { id: "SH-07", name: "Board of Directors", type: "Internal", influence: "Critical", position: "Informed", relationship: "Aligned", health: "Good" },
  { id: "SH-08", name: "Insurance Provider", type: "Vendor", influence: "Medium", position: "Notified", relationship: "Cooperative", health: "Good" },
];

export const BOARD_DECISIONS = [
  { id: "DEC-01", title: "Approve JPDP notification submission", severity: "Critical" as Severity, deadline: "2h 14m", requestedBy: "Legal Counsel", impact: "High", status: "Pending" },
  { id: "DEC-02", title: "Authorise public recall statement", severity: "High" as Severity, deadline: "Today", requestedBy: "Comms Lead", impact: "High", status: "Pending" },
  { id: "DEC-03", title: "Approve vendor contract termination", severity: "Medium" as Severity, deadline: "3 days", requestedBy: "Procurement", impact: "Medium", status: "Review" },
  { id: "DEC-04", title: "Ratify crisis response budget", severity: "Low" as Severity, deadline: "1 week", requestedBy: "CFO", impact: "Low", status: "Pending" },
];

export const BOARD_BRIEFS = [
  { id: "BRF-01", title: "Product Recall — Board Brief", incident: "INC-2026-014", date: "7 Nov 2026", status: "Submitted", pages: 12 },
  { id: "BRF-02", title: "Data Breach — Risk Assessment", incident: "INC-2026-013", date: "6 Nov 2026", status: "Draft", pages: 8 },
  { id: "BRF-03", title: "Regulatory Exposure — Q4", incident: "INC-2026-009", date: "5 Nov 2026", status: "Approved", pages: 6 },
];

export const REGULATORS = [
  { code: "JPDP", name: "Personal Data Protection Department", obligations: 3, open: 1, overdue: 1 },
  { code: "BNM", name: "Bank Negara Malaysia", obligations: 5, open: 2, overdue: 0 },
  { code: "SC", name: "Securities Commission", obligations: 4, open: 1, overdue: 0 },
  { code: "Bursa", name: "Bursa Malaysia", obligations: 6, open: 2, overdue: 0 },
  { code: "MCMC", name: "Malaysian Communications & Multimedia Commission", obligations: 2, open: 1, overdue: 0 },
  { code: "KKM", name: "Ministry of Health", obligations: 3, open: 1, overdue: 0 },
];

export const severityStyles: Record<Severity, string> = {
  Critical: "bg-red-50 text-red-700 border-red-200",
  High: "bg-orange-50 text-orange-700 border-orange-200",
  Medium: "bg-amber-50 text-amber-700 border-amber-200",
  Low: "bg-slate-100 text-slate-600 border-slate-200",
};

export const statusStyles: Record<Status, string> = {
  Open: "bg-blue-50 text-blue-700 border-blue-200",
  "In Progress": "bg-indigo-50 text-indigo-700 border-indigo-200",
  Awaiting: "bg-amber-50 text-amber-700 border-amber-200",
  Complete: "bg-green-50 text-green-700 border-green-200",
  Overdue: "bg-red-50 text-red-700 border-red-200",
};
