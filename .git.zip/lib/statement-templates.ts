// Statement Studio — template engine (not AI-first).
// Templates drive the process. AI may assist later; MVP is deterministic templates.
// Every template has English + Bahasa Malaysia. Dual = both side by side.

export type StatementTemplateId =
  | "Media Statement"
  | "Internal Memo"
  | "Regulator Notice"
  | "Board Update"
  | "Customer Advisory"
  | "Holding Statement"
  | "Apology";

export const TEMPLATE_IDS: StatementTemplateId[] = [
  "Holding Statement",
  "Media Statement",
  "Apology",
  "Regulator Notice",
  "Internal Memo",
  "Board Update",
  "Customer Advisory",
];

type Vars = { title: string; org: string; date: string; spokesperson: string; contact: string };

export const TEMPLATES: Record<StatementTemplateId, { en: (v: Vars) => string; bm: (v: Vars) => string }> = {
  "Holding Statement": {
    en: (v) => `FOR IMMEDIATE RELEASE\n${v.date}\n\n${v.org} — Holding Statement\n\nWe are aware of the incident relating to "${v.title}" and are actively investigating. The safety and interests of those affected remain our priority. We will provide a further update as soon as verified information is available.\n\n— ${v.spokesperson}, ${v.org}\nMedia contact: ${v.contact}`,
    bm: (v) => `UNTUK EDARAN SEGERA\n${v.date}\n\n${v.org} — Kenyataan Pegangan\n\nKami menyedari insiden berkaitan "${v.title}" dan sedang menjalankan siasatan. Keselamatan dan kepentingan pihak yang terjejas kekal menjadi keutamaan kami. Kami akan memberi kemas kini sebaik sahaja maklumat yang disahkan tersedia.\n\n— ${v.spokesperson}, ${v.org}\nHubungan media: ${v.contact}`,
  },
  "Media Statement": {
    en: (v) => `FOR IMMEDIATE RELEASE\n${v.date}\n\n${v.org} — Media Statement on "${v.title}"\n\n${v.org} confirms that an incident has occurred. We have taken immediate steps to contain the situation and are working with the relevant authorities. A full investigation is underway.\n\nWe are committed to transparency and will share further details as they are confirmed.\n\n— ${v.spokesperson}, ${v.org}\nMedia contact: ${v.contact}`,
    bm: (v) => `UNTUK EDARAN SEGERA\n${v.date}\n\n${v.org} — Kenyataan Media mengenai "${v.title}"\n\n${v.org} mengesahkan bahawa satu insiden telah berlaku. Kami telah mengambil langkah segera untuk mengawal keadaan dan sedang bekerjasama dengan pihak berkuasa berkenaan. Siasatan penuh sedang dijalankan.\n\nKami komited kepada ketelusan dan akan berkongsi butiran lanjutan setelah disahkan.\n\n— ${v.spokesperson}, ${v.org}\nHubungan media: ${v.contact}`,
  },
  Apology: {
    en: (v) => `${v.date}\n\n${v.org} — Apology\n\nWe sincerely apologise to those affected by "${v.title}". We recognise the impact this has caused and accept responsibility. We are taking concrete steps to put things right and to prevent recurrence.\n\n— ${v.spokesperson}, ${v.org}`,
    bm: (v) => `${v.date}\n\n${v.org} — Permohonan Maaf\n\nKami memohon maaf ikhlas kepada pihak yang terjejas akibat "${v.title}". Kami menyedari impak yang ditimbulkan dan menerima tanggungjawab. Kami mengambil langkah konkrit untuk membetulkan keadaan dan mencegah berulangnya peristiwa ini.\n\n— ${v.spokesperson}, ${v.org}`,
  },
  "Regulator Notice": {
    en: (v) => `${v.date}\n\nTo: [Regulator]\nFrom: ${v.org}\nRe: Notification — "${v.title}"\n\nPursuant to our regulatory obligations, ${v.org} hereby notifies your office of the above incident. We are assessing the scope and will provide further information as required. Please acknowledge receipt.\n\n— ${v.spokesperson}, ${v.org} (${v.contact})`,
    bm: (v) => `${v.date}\n\nKepada: [Pihak Berkuasa]\nDaripada: ${v.org}\nPerkara: Pemberitahuan — "${v.title}"\n\nSesuai dengan tanggungjawab kawal selia kami, ${v.org} dengan ini memaklumkan pihak tuan/puan tentang insiden di atas. Kami sedang menilai skop dan akan memberi maklumat lanjut seperti yang diperlukan. Sila akui penerimaan.\n\n— ${v.spokesperson}, ${v.org} (${v.contact})`,
  },
  "Internal Memo": {
    en: (v) => `INTERNAL — ${v.date}\n\nTo: All Staff\nFrom: ${v.spokesperson}, ${v.org}\nRe: "${v.title}"\n\nColleagues, we are managing an active incident. Please direct all external enquiries to ${v.contact}. Do not comment publicly. Further guidance will follow.\n\n— ${v.spokesperson}`,
    bm: (v) => `DALAMAN — ${v.date}\n\nKepada: Semua Kakitangan\nDaripada: ${v.spokesperson}, ${v.org}\nPerkara: "${v.title}"\n\nRakan sekerja, kami sedang menguruskan insiden aktif. Sila halakan semua pertanyaan luaran kepada ${v.contact}. Jangan buat sebarang ulasan awam. Panduan lanjut akan menyusul.\n\n— ${v.spokesperson}`,
  },
  "Board Update": {
    en: (v) => `BOARD UPDATE — ${v.date}\n\nIncident: "${v.title}"\n\nSituation: [summary]\nActions taken: [list]\nRegulatory status: [status]\nDecisions required: [list]\n\n— ${v.spokesperson}, ${v.org}`,
    bm: (v) => `KEMAS KINI LEMBAGA — ${v.date}\n\nInsiden: "${v.title}"\n\nSituation: [ringkasan]\nTindakan diambil: [senarai]\nStatus kawal selia: [status]\nKeputusan diperlukan: [senarai]\n\n— ${v.spokesperson}, ${v.org}`,
  },
  "Customer Advisory": {
    en: (v) => `${v.date}\n\nCustomer Advisory — ${v.org}\n\nWe want to inform our customers about an incident: "${v.title}". If you are affected, here is what you need to know and the steps we are taking. For assistance, contact ${v.contact}.\n\n— ${v.org}`,
    bm: (v) => `${v.date}\n\nNasihat Pelanggan — ${v.org}\n\nKami ingin memaklumkan pelanggan kami tentang insiden: "${v.title}". Jika anda terjejas, berikut adalah perkara yang perlu anda ketahui dan langkah yang kami ambil. Untuk bantuan, hubungi ${v.contact}.\n\n— ${v.org}`,
  },
};
