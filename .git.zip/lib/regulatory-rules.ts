// Obligations Engine™ — Malaysia-specific.
// Enter an incident type → get the obligations you must meet, with deadlines, owners,
// evidence required, status, and the reason/trigger (explainability) before legal references.

export type IncidentType =
  | "Data Breach"
  | "Fatality"
  | "Halal Issue"
  | "Cyber Attack"
  | "Product Recall"
  | "Environmental Incident"
  | "Fake Announcement / Deepfake";

export type Obligation = {
  obligation: string;     // What must I do? (shown first)
  deadline: string;       // By when
  owner: string;          // Who owns it
  evidence: string[];     // Evidence required
  status: "Pending" | "In Progress" | "Complete";
  reason: string;         // Why? (explainability)
  trigger: string;        // What triggered it
  regulator: string;      // Legal reference (shown last)
  regulation: string;
  escalation: string;
};

export const OBLIGATIONS: Record<IncidentType, Obligation[]> = {
  "Data Breach": [
    { obligation: "Notify JPDP and affected data subjects in writing", deadline: "72 hours from awareness", owner: "Data Protection Officer", evidence: ["Breach assessment", "Affected records log", "Notification records", "Remediation steps"], status: "Pending", reason: "Potential significant harm to data subjects", trigger: "Affected customer records identified", regulator: "JPDP", regulation: "PDPA 2010 — s. 46", escalation: "DPO; Board if high risk" },
    { obligation: "Report to BNM Financial Sector Ops", deadline: "Promptly per RM 13", owner: "CISO", evidence: ["Incident report", "Impact assessment"], status: "Pending", reason: "Financial institution data incident", trigger: "Institution is BNM-regulated", regulator: "BNM", regulation: "RM 13 (Technology Risk)", escalation: "CISO + BNM liaison" },
    { obligation: "Notify MCMC if telecom sector", deadline: "Per sector guidelines", owner: "Regulatory Affairs", evidence: ["Sector notification"], status: "Pending", reason: "Telecom / customer data involved", trigger: "Telecom sector nexus", regulator: "MCMC", regulation: "CMA 1998", escalation: "Regulatory affairs" },
  ],
  Fatality: [
    { obligation: "Notify DOSH and preserve scene", deadline: "24 hours", owner: "HSE Officer", evidence: ["Scene photos", "Witness statements", "Incident report"], status: "Pending", reason: "Workplace fatality", trigger: "Death on premises", regulator: "DOSH", regulation: "OSHA 1994", escalation: "HSE officer + CEO" },
    { obligation: "Lodge police report", deadline: "Immediate", owner: "Security", evidence: ["Police report number"], status: "Pending", reason: "Death on premises", trigger: "Fatality confirmed", regulator: "PDRM", regulation: "Police report", escalation: "Legal + Security" },
    { obligation: "Notify KKM if public health risk", deadline: "Promptly", owner: "Medical Officer", evidence: ["Health authority notification"], status: "Pending", reason: "Public health nexus", trigger: "Public health risk identified", regulator: "KKM", regulation: "Public health", escalation: "Medical officer" },
  ],
  "Halal Issue": [
    { obligation: "Notify JAKIM and suspend affected product", deadline: "Promptly", owner: "Halal Compliance Lead", evidence: ["Certification docs", "Batch records", "Lab results"], status: "Pending", reason: "Halal certification integrity", trigger: "Certification discrepancy detected", regulator: "JAKIM", regulation: "Trade Descriptions (Halal) Order", escalation: "Halal compliance lead + COO" },
    { obligation: "Notify KKM Food Safety", deadline: "24 hours", owner: "Quality Lead", evidence: ["Recall notice", "Test results"], status: "Pending", reason: "Consumer health risk", trigger: "Consumer safety concern", regulator: "KKM", regulation: "Food Safety", escalation: "Quality + Comms" },
    { obligation: "Material disclosure to Bursa", deadline: "Per Bursa rules", owner: "Company Secretary", evidence: ["Disclosure draft"], status: "Pending", reason: "Material impact (if listed)", trigger: "Materiality threshold met", regulator: "Bursa", regulation: "Listing Requirements", escalation: "Company Secretary + CFO" },
  ],
  "Cyber Attack": [
    { obligation: "Report to MyCERT / NACSA", deadline: "Promptly", owner: "CISO", evidence: ["IOCs", "Forensic snapshot", "Impact assessment"], status: "Pending", reason: "Cyber incident", trigger: "Active attack confirmed", regulator: "MyCERT / NACSA", regulation: "Cybersecurity", escalation: "CISO + Board" },
    { obligation: "Notify JPDP if personal data breach", deadline: "72 hours", owner: "DPO", evidence: ["Breach assessment"], status: "Pending", reason: "Personal data compromised", trigger: "Personal data in affected systems", regulator: "JPDP", regulation: "PDPA 2010", escalation: "DPO" },
    { obligation: "Report per BNM cyber requirements", deadline: "Per RM 10", owner: "CISO", evidence: ["Incident report"], status: "Pending", reason: "Financial institution", trigger: "BNM-regulated entity", regulator: "BNM", regulation: "RM 10/2025 (Cyber)", escalation: "CISO + BNM liaison" },
  ],
  "Product Recall": [
    { obligation: "Notify KKM and issue recall", deadline: "Promptly", owner: "Quality Lead", evidence: ["Defect report", "Batch records", "Recall notice"], status: "Pending", reason: "Consumer safety", trigger: "Defect affecting consumers", regulator: "KKM", regulation: "Food Safety & Quality", escalation: "Quality + COO" },
    { obligation: "Material announcement to Bursa", deadline: "Per Bursa rules", owner: "Company Secretary", evidence: ["Disclosure"], status: "Pending", reason: "Material disclosure", trigger: "Materiality threshold met", regulator: "Bursa", regulation: "Listing Requirements", escalation: "Company Secretary" },
    { obligation: "Notify KPDNHEP if consumer protection nexus", deadline: "Promptly", owner: "Comms Lead", evidence: ["Recall notice"], status: "Pending", reason: "Consumer rights", trigger: "Consumer protection nexus", regulator: "KPDNHEP", regulation: "Consumer Protection", escalation: "Comms" },
  ],
  "Environmental Incident": [
    { obligation: "Notify DOE and contain", deadline: "24 hours", owner: "HSE Officer", evidence: ["Site photos", "Sample results", "Containment report"], status: "Pending", reason: "Environmental pollution", trigger: "Pollution detected", regulator: "DOE", regulation: "EQA 1974", escalation: "HSE + COO" },
    { obligation: "Notify DOSH if injury", deadline: "24 hours", owner: "HSE Officer", evidence: ["Incident report"], status: "Pending", reason: "Safety nexus", trigger: "Injury reported", regulator: "DOSH", regulation: "OSHA", escalation: "HSE" },
  ],
  "Fake Announcement / Deepfake": [
    { obligation: "Report to MCMC, escalate to platform, issue public clarification", deadline: "Promptly", owner: "Comms Lead", evidence: ["Fake content screenshot", "URL", "Platform report ref", "Clarification statement"], status: "Pending", reason: "Fake announcement / impersonation / deepfake", trigger: "Fake content detected", regulator: "MCMC", regulation: "CMA 1998", escalation: "Comms + Legal" },
    { obligation: "Lodge police report", deadline: "Promptly", owner: "Legal", evidence: ["Police report"], status: "Pending", reason: "Fraud / impersonation", trigger: "Impersonation confirmed", regulator: "PDRM", regulation: "Penal Code", escalation: "Legal" },
  ],
};

export const INCIDENT_TYPES = Object.keys(OBLIGATIONS) as IncidentType[];
